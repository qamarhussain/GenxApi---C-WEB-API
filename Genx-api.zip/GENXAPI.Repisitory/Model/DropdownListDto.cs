﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GENXAPI.Repisitory.Model
{
    public class DropdownListDto
    {
        public string Value { get; set; }
        public string Text { get; set; }
        public string ParentReferenceId { get; set; }
    }
}
